Copyright (c) 2014-2015 IBM

Use of this code is governed by the [IBM Download of Content Agreement](http://www.ibm.com/design/language/legal/download-agreement.shtml) as if the content had been downloaded from [its original source in the IBM Design Language](http://www.ibm.com/design/language/resources.shtml).
